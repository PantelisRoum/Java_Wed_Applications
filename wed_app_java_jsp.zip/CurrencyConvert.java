//Ρούμελης Παντελής
//2249
// Controller 
package mypackage;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/currencyconvert")
public class CurrencyConvert extends HttpServlet {	
	public void doPost(HttpServletRequest rq,HttpServletResponse rs) throws IOException,ServletException {
	    String amountStr = rq.getParameter("amount");
        String currency1 = rq.getParameter("currency1");
        String currency2 = rq.getParameter("currency2");
        currencyDB cyrrencydb = currencyDB.getInstance();
        Model curny1=currencyDB.getExchangeRate(currency1);
        Model curny2=currencyDB.getExchangeRate(currency2);
        double amount = 0.0;
        if (amountStr != null && !amountStr.isEmpty()) {
            try {
                amount = Double.parseDouble(amountStr);
                if(amount<=0) {
                	rq.setAttribute("errormsg", "Λάθος:Παρακαλώ δώστε ένα ποσό μεγαλύτερο του μηδενός");
                    RequestDispatcher dispatcher = rq.getRequestDispatcher("NewFile.jsp");
                    dispatcher.forward(rq, rs);
                    return;	
                }
            } catch (NumberFormatException e) {
                rq.setAttribute("errormsg", "Λάθος:Παρακαλώ δώστε κανονικό ποσό για μετατροπή");
                RequestDispatcher dispatcher = rq.getRequestDispatcher("NewFile.jsp");
                dispatcher.forward(rq, rs);
                return;
            }
        } else {
            rq.setAttribute("errormsg", "Λάθος: Παρακαλώ δώστε ένα ποσό για μετατροπή");
            RequestDispatcher dispatcher = rq.getRequestDispatcher("NewFile.jsp");
            dispatcher.forward(rq, rs);
            return;
        }
        double result=convertFunction(amount,curny1,curny2);
        rq.setAttribute("result",result);
        RequestDispatcher dispatcher=rq.getRequestDispatcher("NewFile.jsp");
        dispatcher.forward(rq, rs);

	}
	public double convertFunction(double amount,Model curny1,Model curny2) { 
		double rate1=curny1.getVALUE();
		double rate2=curny2.getVALUE();
		if(curny1.getCode()==curny2.getCode()) {
			return amount;
		}
		if(curny1.getCode()=="EUR") {
			return amount*rate2;
		}
		// we are converting any type currency to euro 
		double amount_in_EURO=amount/rate1;
		//from Euro we are converting to any anther currency 
		return amount_in_EURO*rate2;
	}

	public void doGet(HttpServletRequest rq,HttpServletResponse rs)throws IOException,ServletException {
		doPost(rq,rs);
	}
	

}
