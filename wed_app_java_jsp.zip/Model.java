//Ρούμελης Παντελής
//2249
//model 
package mypackage;

public class Model {
	private String code;
	private String name;
	private double VALUEinEURO;
	public Model() {
		
	}
	public Model(String code,String name, double VALUEinEURO) {
		this.code=code;
		this.name=name;
		this.VALUEinEURO=VALUEinEURO;
	}
	public void setCode(String code) {
		this.code=code;
	}
	public String getCode() {
		return code;
	}
	public void setName(String name) {
		this.name=name;
	}
	public String getName() {
		return name;
	}
	public void setVALUE(double VALUEinEURO) {
		this.VALUEinEURO=VALUEinEURO;
	}
	public double getVALUE() {
		return VALUEinEURO;
	}
}
