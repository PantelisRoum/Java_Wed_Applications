//Ρούμελης Παντελής
//2249
// Singleton class HashMap database

package mypackage;
import java.util.*;

public class currencyDB {
	private static currencyDB instance=null;
	private static Map<String,Model> exchangeMap=new HashMap<>();
	private currencyDB() {}
	public static currencyDB getInstance() {
		if (instance==null) {
			instance=new currencyDB();
			instance.init();
		}
		return instance;
	}
	public void init() {
		exchangeMap.put("EUR",new Model("EUR","Ευρώ",100));
		exchangeMap.put("USD",new Model("USD","Δολλάριο ΗΠΑ",106));
		exchangeMap.put("GBP",new Model("GBP","Λίρα Αγγλίας",86));
		
		
	}
	public static Model getExchangeRate(String code) {
		
		return exchangeMap.get(code);
		
	}

}
